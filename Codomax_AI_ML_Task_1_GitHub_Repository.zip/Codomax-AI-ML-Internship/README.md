# Codomax AI & ML Internship — Task 1

Beginner-level learning notes and Python practice programs for **Module 01: Introduction to AI & Python**.

## Contents
- `Task_1/AI_ML_Introduction.md` — concepts, applications, Python setup, programs and outputs.
- `Python_Programs/` — seven separate Python scripts.

## How to run
1. Install Python 3 from https://www.python.org/downloads/ or use an online Python editor.
2. Open a terminal in `Python_Programs`.
3. Run a script, for example: `python hello_world.py` (or `python3 hello_world.py`).

## Before submission
- Run each program yourself and understand its output.
- In `variables.py`, replace the sample age with your actual age if you keep that field.
- Upload this folder to a GitHub repository in your own account.
- Upload the learning notes to Google Docs or Notion and give your reviewer view access.
